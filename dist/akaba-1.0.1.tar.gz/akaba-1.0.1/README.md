# akaba
This is a CLI scaffolding tool for FastAPI. It helps create a project structure template with boilerplate code
